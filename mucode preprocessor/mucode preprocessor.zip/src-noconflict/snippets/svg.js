﻿ace.define("ace/snippets/svg",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "svg";

});
